//
//  YPSDX.h
//  YPSDX
//
//  version 1.0
//
//  Created by luochenxun on 2018/12/21.
//  Copyright © 2018 yunplus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface YPSDX : NSObject



/**
 初始化sdk release模式
 release 不可用于调试，否则会闪退
 */
+ (void)startSDK;

/**
初始化sdk debug模式
 */
+ (void)startSDKDebugMode;


/**
 导航至SDK相关页面

 @param url 页面对应url
 @param returnUrl 页面对应returnURL
 @param navi 导航控件
 @param completion sdk操作完成后回调(比如支付接口，则表示支付完成), response表示完成后返回的数据
 */
+ (void)actionWithUrl:(NSString *)url
            returnUrl:(NSString *)returnUrl
           navigation:(UINavigationController *)navi
           completion:(void (^)(NSDictionary *response))completion DEPRECATED_ATTRIBUTE;


/**
 导航至SDK相关页面

 @param URL 页面对应URL
 @param returnURL 页面对应returnURL
 @param navi 导航控件
 @param success sdk操作成功后回调(比如支付接口，则表示支付成功）
 @param failure sdk操作失败回调(比如支付接口，则表示支付失败）
 */
+ (void)actionWithURL:(nonnull NSString *)URL
            returnURL:(nullable NSString *)returnURL
           navigation:(nullable UINavigationController *)navi
              success:(nullable void (^)(NSDictionary *response))success
              failure:(nullable void (^)(NSDictionary *response, NSError *error))failure;

@end

